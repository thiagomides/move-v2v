//
// Copyright (C) 2016 David Eckhoff <david.eckhoff@fau.de>
//
// Documentation for these modules is at http://veins.car2x.org/
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include <veins/modules/application/traci/MOVE.h>

Define_Module(MOVE);

void MOVE::initialize(int stage) {
    BaseWaveApplLayer::initialize(stage);

    if (stage == 0) {
        //Initializing members and pointers of your application goes here
        EV << "Initializing " << par("appName").stringValue() << std::endl;

        request = new cMessage("request");
        rerouting = new cMessage("rerouting");
        TimeToLive = par("TimeToLive").doubleValue();

        rerouteInterval = par("rerouteInterval").doubleValue();
        interval = par("interval").doubleValue();

        protection = par("protection");
        next_time_request = simTime().dbl() + interval;
        scheduleAt(next_time_request, request);
        scheduleAt(simTime() + rerouteInterval, rerouting);



    }
    else if (stage == 1) {
        //Initializing members that require initialized other modules goes here
        knowledge_table = mobility->getMap();
        plannedRoad = traciVehicle->getPlannedRoadIds();


        nMsg = 0;
        localCongestion = 1;

        lastLocalCongestion = 1;
        lastOverThreshold = 0;

        lastAboveThreshold = 0;

        sentMessage = false;

    }
    inc = 10.0;
    knowledge = 0;

    travelDistance = traciVehicle->getLanePosition();
    newRoad();

    attacaker_type = mobility->getAttacakerType();
    attacker = mobility->isAttacker();

    AmIAttacker = attacker;


}

void MOVE::finish() {
    BaseWaveApplLayer::finish();


    recordScalar("AmIAttacker",AmIAttacker); // Yes or No
    recordScalar("timesRecognizedAsAttacker",timesRecognizedAsAttacker);
    recordScalar("timesRecognizedAsAttackerConsensus",timesRecognizedAsAttackerConsensus);

    recordScalar("sizeOfMyRoute",sizeOfMyRoute);
    recordScalar("numberOfRoadRecognizedAsAttacker",numberOfRoadRecognizedAsAttacker);


    //statistics recording goes here

}

void MOVE::reRoute(std::string roadId){
    traciVehicle->changeRoute(roadId, knowledge_table[roadId].weights.back().weight * (knowledge_table[roadId].length / knowledge_table[roadId].speed));
    plannedRoad = traciVehicle->getPlannedRoadIds();
}

void MOVE::reroutingP(std::string roadId){
    if (!plannedRoad.empty()){
        road_reroute = mobility->getRoadId();
        if (knowledge_table[plannedRoad.front()].length > 30) {
            updateWeights();
            reRoute(roadId);
            plannedRoad = traciVehicle->getPlannedRoadIds();
        }
    }

}

int MOVE::createAttack(){
    std::srand(std::time(nullptr)); // use current time as seed for random generator

   if (attacaker_type == RANDOM) return 1 + std::rand() % 10;
   if (attacaker_type == MAX_LEVEL) return 10;
   if (attacaker_type  == REVERSE) return ((localCongestion * -1) + (11));
   return -1;

}

void MOVE::newRoad(){
    if (simTime().dbl() > 10)   sizeOfMyRoute++;

    consensus = 0;

    weight now_weight;
    now_weight.time_receive = simTime().dbl();
    knowledge_table[road_id].last_update = simTime().dbl();

    now_weight.weight = localCongestion;
    knowledge_table[road_id].weights.insert(knowledge_table[road_id].weights.end(), now_weight);

    road_id = mobility->getRoadId();
    travelDistance = traciVehicle->getLanePosition();
    reroutingFlag = false;

    lastLocalCongestion = 1;
    localCongestion = 1;

    lastAboveThreshold = 0;
    timeInRoad = 1;

    for(std::list<std::string>::const_iterator it = plannedRoad.begin(); it != plannedRoad.end(); it++){
        if (road_id == it->c_str()){
            plannedRoad.remove(road_id);
            break;
        }
    }

    travelTime  = simTime().dbl();

    knowledge_table[road_id].leaders.id_message = -1;
    knowledge_table[road_id].leaders.leader_id = myId;

    knowledge_table[road_id].leaders.timeInRoad = -1;
    knowledge_table[road_id].leaders.last_election = simTime().dbl();
    knowledge_table[mobility->getRoadId()].leaders.sentMessage = false;
    isMonitor = false;

    neighbor_list.clear();
    road_black_list.clear();
    road_suspect_list.clear();
    road_black_list_consensus.clear();
    attacker_on_road = false;

}

bool MOVE::inMap(std::map<int,double> base_vector, int node_id){
    for( const auto& sm_pair : base_vector){
       if (node_id == sm_pair.first) {
           return true;
       }
   }
   return false;
}


std::vector<std::string> MOVE::checkAmountKnowledge(std::string roadId){
    std::vector<std::string> no_knowledge;
    for( const auto& sm_pair : knowledge_table[roadId].adj_list){
        if (simTime().dbl() - knowledge_table[sm_pair.first].weights.back().time_receive > TimeToLive)
            if (knowledge_table[sm_pair.first].length < 30) continue;
            no_knowledge.push_back(sm_pair.first);
    }
    return no_knowledge;
}



void MOVE::knowledgeRequest(std::vector<std::string> vectorKnowledgeAmount){
    std::string data_msg;
    unsigned int i = 0;
    WaveShortMessage* wsm = new WaveShortMessage();
    populateWSM(wsm);
    for (std::vector<std::string>::iterator it = vectorKnowledgeAmount.begin() ; it != vectorKnowledgeAmount.end(); ++it){
        i++;
        data_msg += it->c_str();
        if (i < vectorKnowledgeAmount.size())   data_msg += ",";

        weight now_weight;
        knowledge_table[it->c_str()].last_update = simTime().dbl();
        now_weight.time_receive = simTime().dbl();
        now_weight.weight = 1;
        knowledge_table[it->c_str()].weights.insert(knowledge_table[it->c_str()].weights.end(), now_weight);


    }

    wsm->setWsmData(data_msg.c_str());
    wsm->setKind(LEADER_DISCOVERY);
    sendDown(wsm);
}


void MOVE::updateKnowledge(std::map<std::string, road_table> knowledge_of_others){
    for( const auto& sm_pair : knowledge_table ){

        if (knowledge_table[sm_pair.first].last_update > knowledge_of_others[sm_pair.first].last_update) continue;

        knowledge_table[sm_pair.first].last_update = knowledge_of_others[sm_pair.first].last_update;
        knowledge_table[sm_pair.first].weights.back().weight = knowledge_of_others[sm_pair.first].weights.back().weight;
    }
}

void MOVE::updateWeights(){
    weight now_weight;
    now_weight.time_receive = simTime().dbl();
    knowledge_table[road_id].last_update = simTime().dbl();

    now_weight.weight = localCongestion;
    knowledge_table[road_id].weights.insert(knowledge_table[road_id].weights.end(), now_weight);

    for( const auto& sm_pair : knowledge_table ){
        if ((sm_pair.first == "") || (sm_pair.first[0] == ':')) continue;
        traciVehicle->setTravelTime(sm_pair.first, knowledge_table[sm_pair.first].weights.back().weight * (knowledge_table[sm_pair.first].length / knowledge_table[sm_pair.first].speed));
    }
}


float MOVE::congestionEstimate(){
    return std::min(10.0,(1 + std::floor(lastAboveThreshold/inc)));
}

bool MOVE::isPlannedRoad(std::list<std::string> table_id, std::string senderId){
    for(std::list<std::string>::const_iterator it = table_id.begin(); it != table_id.end(); it++){
        if ((it->c_str() ==  senderId) && (senderId != mobility->getRoadId())) return true;
    }
    return false;
}

void MOVE::leaderDiscovery(){
    if (knowledge_table[mobility->getRoadId()].leaders.sentMessage == true) return;

    knowledge_table[mobility->getRoadId()].leaders.sentMessage = true;
    knowledge_table[mobility->getRoadId()].leaders.last_election = simTime().dbl();

    BasicSafetyMessage* bsm = new BasicSafetyMessage();
    populateWSM(bsm);

    bsm->setTimestamp(timeInRoad);
    bsm->setKind(LEADER_RESPONSE);

    bsm->setSenderAddress(myId);
    bsm->setRoadId(mobility->getRoadId().c_str());
    //bsm->setCongestionLevel(localCongestion);

    if (attacker)  bsm->setCongestionLevel(createAttack());
   else bsm->setCongestionLevel(localCongestion);

    scheduleAt(simTime().dbl() + 10.0/timeInRoad + uniform(0.01,(1.0/(traciVehicle->getLanePosition()/knowledge_table[mobility->getRoadId()].length))) , bsm->dup());

}



void MOVE::leaderElection(BasicSafetyMessage* receive_bsm){
    if (receive_bsm->getTimestamp().dbl() < knowledge_table[road_id].leaders.timeInRoad) return;
    knowledge_table[receive_bsm->getRoadId()].leaders.id_message = receive_bsm->getId();

    knowledge_table[receive_bsm->getRoadId()].leaders.leader_id = receive_bsm->getSenderAddress();
    knowledge_table[receive_bsm->getRoadId()].leaders.timeInRoad = receive_bsm->getTimestamp().dbl();

}



void MOVE::onBSM(BasicSafetyMessage* bsm) {
    if  (protection){
        if (bsm->getKind() == SEND_BEACON_EVT){
            double ratio;
            for( const auto& sm_pair : neighbor_list){
                ratio += sm_pair.second;
            }
            double standardDeviation;
            for( const auto& sm_pair : neighbor_list){
                standardDeviation += pow(sm_pair.second - (ratio/neighbor_list.size()), 2);
            }
            // Did the beacon address to my road?
            if  (road_id == bsm->getRoadId()){


                for (int var = 0; var < bsm->getBlack_listArraySize(); ++var) {
                    if ((bsm->getBlack_list(var) > 0) && (bsm->getBlack_list(var) == myId))   {
                        timesRecognizedAsAttacker++;
                        consensus++;
                        if (consensus == 3){
                            timesRecognizedAsAttackerConsensus++;
                            consensus = 0;
                        }
                        if (attacker_on_road == false){
                            numberOfRoadRecognizedAsAttacker++;
                            attacker_on_road = true;

                        }
                    }
                }


                // Does my neighbor sending me its black list?
                if (inMap(neighbor_list, bsm->getSenderAddress())) {
                    for (int var = 0; var < bsm->getBlack_listArraySize(); ++var) {
                        if (bsm->getBlack_list(var) > 0)  {
                            if (!inMap(road_black_list_consensus, bsm->getBlack_list(var))) road_black_list_consensus.insert(std::make_pair(bsm->getBlack_list(var), 1 ));
                            else road_black_list_consensus[bsm->getBlack_list(var)] +=  1; // update the node measure

                        }

                    }
                }

                // Isn't the node my on my list?
                if (!inMap(neighbor_list, bsm->getSenderAddress())){
                    // Do I have previous neighbors?
                    if (neighbor_list.size() > 2){
                        // Check if the node can group by its measure.
                        if ((bsm->getCongestionLevel() > (ratio/neighbor_list.size()) - (standardDeviation + 1)) && (bsm->getCongestionLevel() < (ratio/neighbor_list.size()) +  (standardDeviation + 1))){
                            // Insert a new node
                            neighbor_list.insert(std::make_pair(bsm->getSenderAddress(), bsm->getCongestionLevel() ));

                        } else {
                            // Insert the node on the suspect set
                            if (!inMap(suspect_list, bsm->getSenderAddress())) suspect_list.insert(std::make_pair(bsm->getSenderAddress(), 1 ));
                            else  suspect_list[bsm->getSenderAddress()] +=  1; // updating the hitting node on the suspect list

                            if ((suspect_list[bsm->getSenderAddress()] > 3 )){
                                if (!inMap(black_list_nodes, bsm->getSenderAddress()))  black_list_nodes.insert(std::make_pair(bsm->getSenderAddress(), 1 ));
                                else black_list_nodes[bsm->getSenderAddress()] +=  1; // update the node measure
                            }

                            if (!inMap(road_suspect_list, bsm->getSenderAddress())) road_suspect_list.insert(std::make_pair(bsm->getSenderAddress(), 1 ));
                            else  road_suspect_list[bsm->getSenderAddress()] +=  1; // updating the hitting node on the suspect list

                            if (road_suspect_list[bsm->getSenderAddress()] > 3 ) {
                                if (!inMap(road_black_list, bsm->getSenderAddress())){
                                    road_black_list.insert(std::make_pair(bsm->getSenderAddress(), 1 ));
                                    n_black_list_nodes.push_back(bsm->getSenderAddress());
                                }
                                else {
                                    road_black_list[bsm->getSenderAddress()] +=  1; // update the node measure
                                }
                            }
                        }
                    } else {
                        // Is the evaluated node able to entry on my list?
                        if ((bsm->getTimestamp() < 5) && (bsm->getCongestionLevel() > localCongestion  + 1)){
                        } else neighbor_list.insert(std::make_pair(bsm->getSenderAddress(), bsm->getCongestionLevel()));
                    }

                }
                else{

                    // Is the node my on my list?
                    if (inMap(black_list_nodes, bsm->getSenderAddress()))   neighbor_list.erase(bsm->getSenderAddress());
                     else if (inMap(road_black_list_consensus, bsm->getSenderAddress())){
                        if (road_black_list_consensus[bsm->getSenderAddress()] > 3)  neighbor_list.erase(bsm->getSenderAddress());
                    } else if (inMap(road_black_list, bsm->getSenderAddress())){
                        if (road_black_list[bsm->getSenderAddress()] > 3)   neighbor_list.erase(bsm->getSenderAddress());
                    }else  neighbor_list[bsm->getSenderAddress()] =  bsm->getCongestionLevel(); // update the node measure

                }

                return;

            }
    }
    // Does it on consensus black list?
    if ((road_id == bsm->getRoadId()) && (inMap(road_black_list_consensus, bsm->getSenderAddress()))) return;

    if ((!inMap(black_list_nodes, bsm->getSenderAddress()))) {

        switch (bsm->getKind()){
            case LEADER_RESPONSE:
                leaderElection(bsm);
            break;
        }



        knowledge_table[bsm->getRoadId()].id = bsm->getSenderAddress();
        weight now_weight;



        now_weight.time_receive = bsm->getTimestamp();
        now_weight.weight = bsm->getCongestionLevel();


        knowledge_table[bsm->getRoadId()].weights.insert(knowledge_table[bsm->getRoadId()].weights.end(), now_weight);
        knowledge_table[bsm->getRoadId()].last_update = simTime().dbl();

        knowledge_table[bsm->getRoadId()].timeInRoad = bsm->getTimestamp().dbl();
        knowledge_table[bsm->getRoadId()].ids.push_back(bsm->getEncapsulationTreeId());

        }
    }

}

void MOVE::sendBSM() {
    BasicSafetyMessage* bsm = new BasicSafetyMessage();
    populateWSM(bsm);

    weight now_weight;
    now_weight.time_receive = simTime().dbl();
    now_weight.weight = bsm->getCongestionLevel();

    knowledge_table[road_id].id = myId;
    knowledge_table[road_id].timeInRoad = timeInRoad;

    knowledge_table[road_id].last_update = simTime().dbl();
    knowledge_table[bsm->getRoadId()].weights.insert(knowledge_table[bsm->getRoadId()].weights.end(), now_weight);

    if (attacker)  bsm->setCongestionLevel(createAttack());
    else bsm->setCongestionLevel(localCongestion);



    bsm->setRoadId(road_id.c_str());
    bsm->setTimestamp(timeInRoad);
    bsm->setSenderAddress(myId);
    bsm->setRecipientAddress(-1);

    bsm->setKind(KNOWLEDGE_SHARE);

    if (knowledge_table[mobility->getRoadId()].leaders.leader_id == myId)   scheduleAt(simTime().dbl() + uniform(0.01,(2.0)) , bsm->dup());
    delete(bsm);

}

std::string MOVE::checkRoad(std::string wsm_data){

    std::string delimiter = ",";
    size_t pos = 0;
    size_t pos2 = 0;
    while ((pos = wsm_data.find(delimiter, pos)) < wsm_data.length()) {
        if (wsm_data.substr(pos2, pos - pos2) ==  road_id) return wsm_data.substr(pos2, pos - pos2);
        pos += delimiter.length();
        pos2 = pos;
    }
    if (wsm_data.substr(pos2, pos - wsm_data.length()) == road_id) return wsm_data.substr(pos2, pos - pos2);
    return "";
}

void MOVE::onWSM(WaveShortMessage* wsm) {
    findHost()->getDisplayString().updateWith("r=16,green");
    std::string road_request;
    road_request = checkRoad(wsm->getWsmData());
    if (!road_request.empty()) leaderDiscovery(); // Request Information


}


void MOVE::handleSelfMsg(cMessage* msg) {
    // Beacon position control

    if(msg == request){
        std::vector<std::string> requestList = checkAmountKnowledge(road_id);
        if (requestList.size()/knowledge_table[road_id].adj_list.size() > 0.8) knowledgeRequest(checkAmountKnowledge(road_id)); // Send message with road list;
        next_time_request = simTime().dbl() + interval;
        scheduleAt(next_time_request, request);
        return;


    } else if(msg == rerouting)  {
        reroutingFlag = true;
        scheduleAt(simTime() + rerouteInterval, rerouting);
        return;
    }
    if  (protection){
        if ((msg->getKind() == SEND_BEACON_EVT)){

            BasicSafetyMessage* bsm_new = new BasicSafetyMessage();
            populateWSM(bsm_new);

            if (attacker)  bsm_new->setCongestionLevel(createAttack());
            else bsm_new->setCongestionLevel(localCongestion);

            int i = 0;
            if (!attacker) {
                for(std::vector<int>::const_iterator it = n_black_list_nodes.begin(); it != n_black_list_nodes.end(); it++){
                    bsm_new->setBlack_list(i, *it);
                    i++;
                    if (i > 9) break;
                }
            }
            n_black_list_nodes.clear();

            bsm_new->setSenderAddress(myId);
            bsm_new->setNeighborSize(neighbor_list.size());
            bsm_new->setTimestamp(timeInRoad);


            bsm_new->setKind(SEND_BEACON_EVT);
            bsm_new->setRoadId(road_id.c_str());
            if (attacker) {
                if (simTime().dbl() > 10) {
                    sendDown(bsm_new);
                }
            } else sendDown(bsm_new);


            scheduleAt(simTime() + beaconInterval, sendBeaconEvt);
        }

    }
    if (BasicSafetyMessage* bsm  = dynamic_cast<BasicSafetyMessage*>(msg)){
        switch (bsm->getKind()){
            case LEADER_RESPONSE:
                if ((bsm->getTimestamp().dbl() <  knowledge_table[bsm->getRoadId()].leaders.timeInRoad) || (mobility->getRoadId() != bsm->getRoadId())){
                    delete(bsm);
                    return;
                }

                knowledge_table[bsm->getRoadId()].leaders.timeInRoad =   bsm->getTimestamp().dbl();
                sendDown(bsm->dup());
                delete(bsm);
                return;
            break;
            case KNOWLEDGE_SHARE:
                if (mobility->getRoadId() != bsm->getRoadId()) return; // Am I on bsm->road?
                if (knowledge_table[bsm->getRoadId()].leaders.leader_id != myId) return; // Am I leader?
                sendDown(bsm->dup());
                delete(bsm);

                return;
            break;
        }

    }
}

void MOVE::handlePositionUpdate(cObject* obj) {
    BaseWaveApplLayer::handlePositionUpdate(obj);
    if (mobility->getRoadId()[0] == ':') return;
    if (road_id != mobility->getRoadId()) newRoad();

    if (((traciVehicle->getLanePosition()/knowledge_table[mobility->getRoadId()].length) > 0.95) && (reroutingFlag) && (!plannedRoad.empty())){
        reroutingFlag = false;
        reroutingP(plannedRoad.front()); // Send message with road list;
    }


    /*
    expectedDistance =  (simTime().dbl() - travelTime) *  knowledge_table[road_id].speed * 0.7135;
    if (expectedDistance < 1) return;

    if (traciVehicle->getLanePosition() < expectedDistance) lastAboveThreshold += std::min(10.0,expectedDistance / traciVehicle->getLanePosition()); // Last time above the threshold (lastAboveThreshold of big value and lastOverThreshold of small value -> traffic clean)
    localCongestion = congestionEstimate();

    lastLocalCongestion = localCongestion;

    accelaration_time = ((knowledge_table[mobility->getRoadId()].speed - mobility->getSpeed())/acceleration);
    accelaration_distance = 0.5 * (acceleration * pow(accelaration_time,2));
     */

    accelaration_time = ((knowledge_table[mobility->getRoadId()].speed - mobility->getSpeed())/acceleration);
    accelaration_distance = 0.5 * (acceleration * pow(accelaration_time,2));


    if ((knowledge_table[mobility->getRoadId()].length - accelaration_distance - traciVehicle->getLanePosition()) > 0){
        predictive_travel_time = accelaration_time + timeInRoad + ((knowledge_table[mobility->getRoadId()].length - accelaration_distance - traciVehicle->getLanePosition())/knowledge_table[mobility->getRoadId()].speed);
        localCongestion = predictive_travel_time/knowledge_table[mobility->getRoadId()].expected_travelTime;
    } else {
        accelaration_time = pow((2 * (knowledge_table[mobility->getRoadId()].length - traciVehicle->getLanePosition()))/acceleration , 0.5);
        predictive_travel_time = accelaration_time + timeInRoad;
        localCongestion = predictive_travel_time/knowledge_table[mobility->getRoadId()].expected_travelTime;

    }
    if (localCongestion < 1) localCongestion = 1;

    timeInRoad++;

}


