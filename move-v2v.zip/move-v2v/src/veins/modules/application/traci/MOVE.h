//
//
// Documentation for these modules is at http://veins.car2x.org/
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#ifndef __VEINS_MOVE_H_
#define __VEINS_MOVE_H_

#include <omnetpp.h>
#include "veins/modules/application/ieee80211p/BaseWaveApplLayer.h"
#include <numeric>


using namespace omnetpp;

/**
 * @brief
 * This is a stub for a typical Veins application layer.
 * Most common functions are overloaded.
 * See MOVE.cc for hints
 *
 * @author David Eckhoff
 *
 */


class MOVE : public BaseWaveApplLayer {
    public:
        virtual void initialize(int stage);
        virtual void finish();



        enum MessageType {
            SEND_BEACON_EVT = 0,
            KNOWLEDGE_SHARE = 1,
            KNOWLEDGE_REQUEST = 2,

            LEADER_DISCOVERY = 3,
            LEADER_RESPONSE = 4,

            MONITOR_ROAD = 5,
            KNOWLEDGE_FORWARD = 6,


        };

    protected:
        double localCongestion;
        int lastLocalCongestion;

        int lastDroveAt;
        int lastRegion;

        int nMsg;
        int knowledge;

        bool sentMessage;
        bool isMonitor;
        bool completeKnowledge;
        bool reroutingFlag;

        double expectedDistance;
        double travelTime;

        double travelDistance;
        double lastTimeReRoute;

        double interval;
        double rerouteInterval;

        double timeInRoad;
        double lastCongestionUpdate;

        double itm;
        double inc;

        double TimeToLive;

        Coord wsm_sender;

        std::string road_id;
        std::string road_reroute;

        std::list<std::string> plannedRoad;
        std::map<std::string, road_table> knowledge_table;

        int lastAboveThreshold;
        int lastOverThreshold;

        std::vector<int> wsm_history;


        cMessage* request;
        cMessage* rerouting;

        double next_time_request;




        double acceleration = 2.9;
       double predictive_travel_time;
       double accelaration_time;
       double accelaration_distance;


        // Confinit parameters


       uint32_t timesRecognizedAsAttacker = 0;
       uint32_t timesRecognizedAsAttackerConsensus = 0;

       uint32_t sizeOfMyRoute = 0;
       uint32_t numberOfRoadRecognizedAsAttacker = 0;

       uint32_t AmIAttacker = 0;




        std::map<int,double> black_list_nodes;
        std::map<int,double> neighbor_list;
        std::map<int,double> suspect_list;

        // One road list
        std::map<int,double> road_black_list;
        std::map<int,double> road_black_list_consensus;

        std::map<int,double> road_suspect_list;

        std::vector<int> n_black_list_nodes;

        bool attacker_on_road = false;
        int consensus = 0;

        bool protection;


        enum AttackerType {
          NO_ATTACK = 0,
          RANDOM = 1,
          MAX_LEVEL = 2,
          REVERSE = 3,
        };




        bool attacker = false;
        int attacaker_type = NO_ATTACK;


    protected:

        virtual void onBSM(BasicSafetyMessage* bsm);
        virtual void sendBSM();

        virtual void onWSM(WaveShortMessage* wsm);

        virtual void handleSelfMsg(cMessage* msg);
        virtual void handlePositionUpdate(cObject* obj);

        virtual bool isPlannedRoad(std::list<std::string> table_id, std::string senderId);

        virtual float congestionEstimate();
        virtual void updateWeights();

        virtual void leaderElection(BasicSafetyMessage* receive_bsm);
        virtual void leaderDiscovery();


        virtual void reRoute(std::string roadId);
        virtual void reroutingP(std::string roadId);

        virtual void newRoad();

        virtual void knowledgeRequest(std::vector<std::string>);

        virtual void updateKnowledge(std::map<std::string, road_table> knowledge_of_others);

        virtual std::vector<std::string> checkAmountKnowledge(std::string roadId);
        virtual std::string checkRoad(std::string wsm_data);

        virtual int createAttack();

        virtual bool inMap(std::map<int,double> base_vector, int node_id);


    };

#endif
