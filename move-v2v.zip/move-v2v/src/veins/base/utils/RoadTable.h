#ifndef _ROADTABLE_H
#define _ROADTABLE_H


struct weight{
    double weight;
    simtime_t  time_receive;
};

struct leader{
    bool sentMessage;
    int id_message;
    int leader_id;
    double timeInRoad;
    simtime_t  last_election;

};

struct road_table{
    // Congestion Level
    std::vector<weight> weights;

    // Road definitions
    std::map<std::string,double> adj_list;
    double length;
    double speed;
    double expected_travelTime;

    // Network definitions
    int id;
    simtime_t  last_update;

    double  timeInRoad;
    leader leaders;

    std::vector<int> ids;
    Coord emit;
};

#endif

